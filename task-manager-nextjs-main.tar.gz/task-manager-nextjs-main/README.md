# Task Manager — Frontend

A task management web application built with **Next.js 16** (App Router), **TypeScript**, **Tailwind CSS**, and **shadcn/ui**.

It connects to the [Task Manager FastAPI backend](https://gitlab.com/iman244/task-manager-fastapi) to manage tasks with full CRUD operations.

## Features

- List tasks with status filtering and pagination
- Create, edit, and delete tasks
- Server-side data fetching via Next.js Server Components
- Form submissions via Next.js Server Actions
- Inline success/error feedback on form submit
- Fully typed API client using OpenAPI-generated types

## Tech Stack

- **Next.js 16** — App Router, Server Components, Server Actions
- **TypeScript** — strict typing throughout
- **Tailwind CSS** — utility-first styling
- **shadcn/ui** — accessible component library
- **Jest + React Testing Library** — unit tests with coverage thresholds

## Requirements

- Node.js 24+
- [Task Manager FastAPI](https://gitlab.com/iman244/task-manager-fastapi) running and accessible

## Environment Variables

| Variable  | Description          | Example                 |
|-----------|----------------------|-------------------------|
| `API_URL` | Backend API base URL | `http://localhost:8000` |

Copy `.env.example` to `.env.local` and fill in the values:

```bash
cp .env.example .env.local
```

## Running Locally

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Running as a Container

### From the GitLab Container Registry

Versioned images are published to the GitLab Container Registry on every release tag (e.g. `v1.0.0`). The `latest` tag always points to the most recent release.

Pull and run the latest release:

```bash
docker run -p 3000:3000 \
  -e API_URL=http://your-api-host:8000 \
  registry.gitlab.com/iman244/task-manager-nextjs:latest
```

Or pin to a specific version:

```bash
docker run -p 3000:3000 \
  -e API_URL=http://your-api-host:8000 \
  registry.gitlab.com/iman244/task-manager-nextjs:v1.0.0
```

### Build Locally

```bash
docker build -t task-manager-frontend .

docker run -p 3000:3000 \
  -e API_URL=http://your-api-host:8000 \
  task-manager-frontend
```

## CI/CD

The pipeline runs on every merge request and push to `develop` and `main`:

| Stage    | Jobs                                     |
|----------|------------------------------------------|
| `lint`   | `gitlint`, `eslint`, `typecheck`         |
| `test`   | Unit tests with coverage thresholds      |
| `build`  | Next.js production build                 |
| `release`| Docker image build and push to registry |

Docker images are tagged with the commit SHA and branch name on `develop`/`main`.
On release tags (e.g. `v1.0.0`), images are also tagged with the version and `latest`.

## Project Structure

```
src/
├── app/
│   ├── tasks/
│   │   ├── page.tsx        # Task list
│   │   ├── actions.ts      # Server actions (create, update, delete)
│   │   ├── new/page.tsx    # New task form
│   │   └── [id]/page.tsx   # Task detail and edit
├── components/
│   ├── tasks/              # Task-specific components
│   └── ui/                 # shadcn/ui components
├── lib/
│   ├── api/tasks.ts        # Typed API client
│   ├── config.ts           # Environment config
│   └── tasks.ts            # Shared task utilities
└── types/
    └── api.ts              # OpenAPI-generated types
```

## Conventional Commits

This project follows [Conventional Commits](https://www.conventionalcommits.org/):

```
feat:     new feature
fix:      bug fix
chore:    maintenance
style:    formatting or visual changes
docs:     documentation
ci:       CI/CD changes
refactor: code change without feature or fix
```
