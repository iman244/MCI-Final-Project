import { parseTaskStatus } from "./tasks";

describe("parseTaskStatus", () => {
  it("returns todo when valid", () => {
    expect(parseTaskStatus("todo")).toBe("todo");
  });

  it("returns in_progress when valid", () => {
    expect(parseTaskStatus("in_progress")).toBe("in_progress");
  });

  it("returns done when valid", () => {
    expect(parseTaskStatus("done")).toBe("done");
  });

  it("returns undefined for invalid status", () => {
    expect(parseTaskStatus("hacked")).toBeUndefined();
  });

  it("returns undefined when missing", () => {
    expect(parseTaskStatus()).toBeUndefined();
  });
});
