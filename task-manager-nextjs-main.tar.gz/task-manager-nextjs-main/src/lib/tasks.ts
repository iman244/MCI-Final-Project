import type { components } from "@/types/api";

type TaskStatus = components["schemas"]["TaskStatus"];

const VALID_STATUSES: TaskStatus[] = [
  "todo",
  "in_progress",
  "done",
];

export function parseTaskStatus(
  status?: string,
): TaskStatus | undefined {
  return VALID_STATUSES.includes(status as TaskStatus)
    ? (status as TaskStatus)
    : undefined;
}
