import { getTasks, getTask, createTask, updateTask, deleteTask } from "@/lib/api/tasks";

const mockTask = {
  id: 1,
  title: "Test task",
  description: "Test description",
  status: "todo" as const,
  created_at: "2024-01-01T00:00:00Z",
  updated_at: "2024-01-01T00:00:00Z",
};

const mockPaginated = {
  items: [mockTask],
  total: 1,
  page: 1,
  page_size: 10,
};

beforeEach(() => {
  global.fetch = jest.fn();
});

afterEach(() => {
  jest.resetAllMocks();
});

describe("getTasks", () => {
  it("fetches tasks without params", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => mockPaginated,
    });

    const result = await getTasks();
    expect(result).toEqual(mockPaginated);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining("/tasks/"));
  });

  it("appends query params when provided", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => mockPaginated,
    });

    await getTasks({ status: "todo", page: 2, page_size: 5 });
    const calledUrl = (fetch as jest.Mock).mock.calls[0][0] as string;
    expect(calledUrl).toContain("status=todo");
    expect(calledUrl).toContain("page=2");
    expect(calledUrl).toContain("page_size=5");
  });

  it("throws on non-ok response", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({ ok: false, status: 500 });
    await expect(getTasks()).rejects.toThrow("Failed to fetch tasks: 500");
  });
});

describe("getTask", () => {
  it("fetches a single task by id", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => mockTask,
    });

    const result = await getTask(1);
    expect(result).toEqual(mockTask);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining("/tasks/1"));
  });

  it("throws on 404", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({ ok: false, status: 404 });
    await expect(getTask(99)).rejects.toThrow("Failed to fetch task 99: 404");
  });
});

describe("createTask", () => {
  it("posts a new task and returns it", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => mockTask,
    });

    const result = await createTask({ title: "Test task", status: "todo" });
    expect(result).toEqual(mockTask);
    expect(fetch).toHaveBeenCalledWith(
      expect.stringContaining("/tasks/"),
      expect.objectContaining({
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: "Test task", status: "todo" }),
      })
    );
  });

  it("throws on non-ok response", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({ ok: false, status: 422 });
    await expect(createTask({ title: "Bad", status: "todo" })).rejects.toThrow(
      "Failed to create task: 422"
    );
  });
});

describe("updateTask", () => {
  it("puts updated fields and returns the task", async () => {
    const updated = { ...mockTask, title: "Updated" };
    (fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => updated,
    });

    const result = await updateTask(1, { title: "Updated" });
    expect(result).toEqual(updated);
    expect(fetch).toHaveBeenCalledWith(
      expect.stringContaining("/tasks/1"),
      expect.objectContaining({ method: "PUT" })
    );
  });

  it("throws on 404", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({ ok: false, status: 404 });
    await expect(updateTask(99, { title: "x" })).rejects.toThrow(
      "Failed to update task 99: 404"
    );
  });
});

describe("deleteTask", () => {
  it("sends DELETE and resolves void", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({ ok: true, status: 204 });

    await expect(deleteTask(1)).resolves.toBeUndefined();
    expect(fetch).toHaveBeenCalledWith(
      expect.stringContaining("/tasks/1"),
      expect.objectContaining({ method: "DELETE" })
    );
  });

  it("throws on 404", async () => {
    (fetch as jest.Mock).mockResolvedValueOnce({ ok: false, status: 404 });
    await expect(deleteTask(99)).rejects.toThrow("Failed to delete task 99: 404");
  });
});