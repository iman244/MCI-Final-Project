import { getApiUrl } from "@/lib/config";
import type { components, operations } from "@/types/api";

type TaskResponse = components["schemas"]["TaskResponse"];
type TaskCreate = components["schemas"]["TaskCreate"];
type TaskUpdate = components["schemas"]["TaskUpdate"];
type PaginatedTasksResponse = components["schemas"]["PaginatedTasksResponse"];

type GetTasksParams = operations["getTasks"]["parameters"]["query"];

export async function getTasks(params?: GetTasksParams): Promise<PaginatedTasksResponse> {
  const url = new URL(`${getApiUrl()}/tasks/`);

  if (params?.status) url.searchParams.set("status", params.status);
  if (params?.title) url.searchParams.set("title", params.title);
  if (params?.page) url.searchParams.set("page", String(params.page));
  if (params?.page_size) url.searchParams.set("page_size", String(params.page_size));

  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`Failed to fetch tasks: ${res.status}`);
  return res.json();
}

export async function getTask(id: number): Promise<TaskResponse> {
  const res = await fetch(`${getApiUrl()}/tasks/${id}`);
  if (!res.ok) throw new Error(`Failed to fetch task ${id}: ${res.status}`);
  return res.json();
}

export async function createTask(data: TaskCreate): Promise<TaskResponse> {
  const res = await fetch(`${getApiUrl()}/tasks/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`Failed to create task: ${res.status}`);
  return res.json();
}

export async function updateTask(id: number, data: TaskUpdate): Promise<TaskResponse> {
  const res = await fetch(`${getApiUrl()}/tasks/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`Failed to update task ${id}: ${res.status}`);
  return res.json();
}

export async function deleteTask(id: number): Promise<void> {
  const res = await fetch(`${getApiUrl()}/tasks/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error(`Failed to delete task ${id}: ${res.status}`);
}
