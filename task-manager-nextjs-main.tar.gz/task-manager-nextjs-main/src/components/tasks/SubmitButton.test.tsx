// src/components/tasks/SubmitButton.test.tsx
import { render, screen } from "@testing-library/react";
import { SubmitButton } from "./SubmitButton";

const mockUseFormStatus = jest.fn();

jest.mock("react-dom", () => ({
  ...jest.requireActual("react-dom"),
  useFormStatus: () => mockUseFormStatus(),
}));

describe("SubmitButton", () => {
  it("renders the label when not pending", () => {
    mockUseFormStatus.mockReturnValue({ pending: false });
    render(<SubmitButton label="Save changes" pendingLabel="Saving..." />);
    expect(screen.getByRole("button", { name: "Save changes" })).toBeInTheDocument();
  });

  it("renders the pending label and is disabled when pending", () => {
    mockUseFormStatus.mockReturnValue({ pending: true });
    render(<SubmitButton label="Save changes" pendingLabel="Saving..." />);
    expect(screen.getByRole("button", { name: "Saving..." })).toBeDisabled();
  });
});
