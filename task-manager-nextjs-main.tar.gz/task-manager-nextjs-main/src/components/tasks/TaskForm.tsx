// src/components/tasks/TaskForm.tsx
"use client";

import { useActionState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SubmitButton } from "./SubmitButton";
import type { ActionState } from "@/app/tasks/actions";
import type { components } from "@/types/api";

type TaskResponse = components["schemas"]["TaskResponse"];

interface TaskFormProps {
  task?: TaskResponse;
  action: (prev: ActionState, formData: FormData) => Promise<ActionState>;
}

export function TaskForm({ task, action }: TaskFormProps) {
  const [state, formAction] = useActionState(action, null);

  return (
    <form action={formAction} className="space-y-4">
      <div className="space-y-1">
        <Label htmlFor="title">Title</Label>
        <Input
          id="title"
          name="title"
          required
          defaultValue={task?.title ?? ""}
          placeholder="Task title"
        />
      </div>

      <div className="space-y-1">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          name="description"
          defaultValue={task?.description ?? ""}
          placeholder="Optional description"
          rows={3}
        />
      </div>

      {task && (
        <div className="space-y-1">
          <Label htmlFor="status">Status</Label>
          <Select name="status" defaultValue={task.status}>
            <SelectTrigger id="status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todo">Todo</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="done">Done</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {state?.success && (
        <p className="text-sm text-green-600">{state.message}</p>
      )}

      {state?.success === false && (
        <p className="text-sm text-destructive">{state.message}</p>
      )}

      <SubmitButton
        label={task ? "Save changes" : "Create task"}
        pendingLabel={task ? "Saving..." : "Creating..."}
      />
    </form>
  );
}
