import { render, screen } from "@testing-library/react";
import { TaskCard } from "./TaskCard";

const mockTask = {
  id: 1,
  title: "Test Task",
  description: "Test description",
  status: "todo" as const,
  created_at: "2024-01-01T00:00:00Z",
  updated_at: "2024-01-01T00:00:00Z",
};

describe("TaskCard", () => {
  it("renders the task title", () => {
    render(<TaskCard task={mockTask} />);
    expect(screen.getByText("Test Task")).toBeInTheDocument();
  });

  it("renders the task description", () => {
    render(<TaskCard task={mockTask} />);
    expect(screen.getByText("Test description")).toBeInTheDocument();
  });

  it("renders the status badge", () => {
    render(<TaskCard task={mockTask} />);
    expect(screen.getByText("Todo")).toBeInTheDocument();
  });

  it("does not render description when null", () => {
    render(<TaskCard task={{ ...mockTask, description: null }} />);
    expect(screen.queryByText("Test description")).not.toBeInTheDocument();
  });

  it("links to the task detail page", () => {
    render(<TaskCard task={mockTask} />);
    expect(screen.getByRole("link")).toHaveAttribute("href", "/tasks/1");
  });
});
