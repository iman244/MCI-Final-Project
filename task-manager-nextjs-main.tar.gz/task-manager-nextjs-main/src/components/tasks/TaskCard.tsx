import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TaskStatusBadge } from "./TaskStatusBadge";
import type { components } from "@/types/api";

type TaskResponse = components["schemas"]["TaskResponse"];

interface TaskCardProps {
  task: TaskResponse;
}

export function TaskCard({ task }: TaskCardProps) {
  return (
    <Link href={`/tasks/${task.id}`}>
      <Card className="hover:shadow-md transition-shadow cursor-pointer">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base font-medium">{task.title}</CardTitle>
          <TaskStatusBadge status={task.status} />
        </CardHeader>
        {task.description && (
          <CardContent>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {task.description}
            </p>
          </CardContent>
        )}
      </Card>
    </Link>
  );
}
