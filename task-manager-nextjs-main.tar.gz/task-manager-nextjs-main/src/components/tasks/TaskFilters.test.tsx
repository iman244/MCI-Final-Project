import { render, screen } from "@testing-library/react";
import { TaskFilters } from "./TaskFilters";

const mockPush = jest.fn();

jest.mock("next/navigation", () => ({
  useRouter: () => ({ push: mockPush }),
  useSearchParams: () => new URLSearchParams(),
}));

describe("TaskFilters", () => {
  it("renders the filter label", () => {
    render(<TaskFilters />);
    expect(screen.getByText("Filter by status:")).toBeInTheDocument();
  });

  it("defaults to 'All' when no status param", () => {
    render(<TaskFilters />);
    expect(screen.getByRole("combobox")).toBeInTheDocument();
  });
});
