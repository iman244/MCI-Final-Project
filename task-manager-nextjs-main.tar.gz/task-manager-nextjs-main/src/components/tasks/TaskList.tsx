import { TaskCard } from "./TaskCard";
import type { components } from "@/types/api";

type TaskResponse = components["schemas"]["TaskResponse"];

interface TaskListProps {
  tasks: TaskResponse[];
}

export function TaskList({ tasks }: TaskListProps) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No tasks found.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-3">
      {tasks.map((task) => (
        <TaskCard key={task.id} task={task} />
      ))}
    </div>
  );
}