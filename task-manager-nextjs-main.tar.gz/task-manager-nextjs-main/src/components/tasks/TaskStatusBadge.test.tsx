import { render, screen } from "@testing-library/react";
import { TaskStatusBadge } from "./TaskStatusBadge";

describe("TaskStatusBadge", () => {
  it("renders 'Todo' for todo status", () => {
    render(<TaskStatusBadge status="todo" />);
    expect(screen.getByText("Todo")).toBeInTheDocument();
  });

  it("renders 'In Progress' for in_progress status", () => {
    render(<TaskStatusBadge status="in_progress" />);
    expect(screen.getByText("In Progress")).toBeInTheDocument();
  });

  it("renders 'Done' for done status", () => {
    render(<TaskStatusBadge status="done" />);
    expect(screen.getByText("Done")).toBeInTheDocument();
  });
});
