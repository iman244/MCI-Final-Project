import { render, screen } from "@testing-library/react";
import { TaskList } from "./TaskList";

const mockTasks = [
  {
    id: 1,
    title: "First Task",
    description: "First description",
    status: "todo" as const,
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
  },
  {
    id: 2,
    title: "Second Task",
    description: null,
    status: "done" as const,
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
  },
];

describe("TaskList", () => {
  it("renders all tasks", () => {
    render(<TaskList tasks={mockTasks} />);
    expect(screen.getByText("First Task")).toBeInTheDocument();
    expect(screen.getByText("Second Task")).toBeInTheDocument();
  });

  it("renders empty state when no tasks", () => {
    render(<TaskList tasks={[]} />);
    expect(screen.getByText("No tasks found.")).toBeInTheDocument();
  });

  it("renders correct number of task cards", () => {
    render(<TaskList tasks={mockTasks} />);
    expect(screen.getAllByRole("link")).toHaveLength(2);
  });
});
