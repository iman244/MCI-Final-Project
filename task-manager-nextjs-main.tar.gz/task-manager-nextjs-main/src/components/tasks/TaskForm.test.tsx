import { render, screen } from "@testing-library/react";
import { TaskForm } from "./TaskForm";

const mockTask = {
  id: 1,
  title: "Existing Task",
  description: "Existing description",
  status: "in_progress" as const,
  created_at: "2024-01-01T00:00:00Z",
  updated_at: "2024-01-01T00:00:00Z",
};

const mockAction = jest.fn();

describe("TaskForm", () => {
  it("renders title and description fields", () => {
    render(<TaskForm action={mockAction} />);
    expect(screen.getByLabelText("Title")).toBeInTheDocument();
    expect(screen.getByLabelText("Description")).toBeInTheDocument();
  });

  it("renders 'Create task' button when no task provided", () => {
    render(<TaskForm action={mockAction} />);
    expect(
      screen.getByRole("button", { name: "Create task" }),
    ).toBeInTheDocument();
  });

  it("renders 'Save changes' button when task is provided", () => {
    render(<TaskForm task={mockTask} action={mockAction} />);
    expect(
      screen.getByRole("button", { name: "Save changes" }),
    ).toBeInTheDocument();
  });

  it("pre-fills fields with task values", () => {
    render(<TaskForm task={mockTask} action={mockAction} />);
    expect(screen.getByLabelText("Title")).toHaveValue("Existing Task");
    expect(screen.getByLabelText("Description")).toHaveValue(
      "Existing description",
    );
  });

  it("does not render status field when no task provided", () => {
    render(<TaskForm action={mockAction} />);
    expect(screen.queryByLabelText("Status")).not.toBeInTheDocument();
  });

  it("renders status field when task is provided", () => {
    render(<TaskForm task={mockTask} action={mockAction} />);
    expect(screen.getByLabelText("Status")).toBeInTheDocument();
  });
});
