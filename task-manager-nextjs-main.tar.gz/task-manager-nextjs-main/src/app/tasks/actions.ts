"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createTask, updateTask, deleteTask } from "@/lib/api/tasks";
import { parseTaskStatus } from "@/lib/tasks";

export type ActionState = {
  success: boolean;
  message: string;
} | null;

export async function createTaskAction(
  _prev: ActionState,
  formData: FormData
): Promise<ActionState> {
  const title = formData.get("title") as string;
  const description = formData.get("description") as string | null;

  const task = await createTask({
    title,
    description: description || null,
    status: "todo",
  });

  revalidatePath("/tasks");
  redirect(`/tasks/${task.id}`);
}

export async function updateTaskAction(
  id: number,
  _prev: ActionState,
  formData: FormData
): Promise<ActionState> {
  const title = formData.get("title") as string;
  const description = formData.get("description") as string | null;
  const status = formData.get("status") as string;

  await updateTask(id, {
    title,
    description: description || null,
    status: parseTaskStatus(status),
  });

  revalidatePath("/tasks");
  revalidatePath(`/tasks/${id}`);

  return { success: true, message: "Task saved successfully." };
}

export async function deleteTaskAction(id: number): Promise<void> {
  await deleteTask(id);
  revalidatePath("/tasks");
  redirect("/tasks");
}
