import Link from "next/link";
import { Suspense } from "react";
import { getTasks } from "@/lib/api/tasks";
import { TaskList } from "@/components/tasks/TaskList";
import { TaskFilters } from "@/components/tasks/TaskFilters";
import { Button } from "@/components/ui/button";
import { parseTaskStatus } from "@/lib/tasks";

export const metadata = {
  title: "Tasks",
  description:
    "View, filter, and manage your tasks. Track progress, organize work, and stay productive with your task dashboard.",
};

interface TasksPageProps {
  searchParams: Promise<{
    status?: string;
    page?: string;
  }>;
}

export default async function TasksPage({ searchParams }: TasksPageProps) {
  const { status, page } = await searchParams;

  const filteredStatus = parseTaskStatus(status);

  const {
    items,
    total,
    page: currentPage,
    page_size,
  } = await getTasks({
    status: filteredStatus,
    page: page ? Number(page) : 1,
    page_size: 10,
  });

  const totalPages = Math.ceil(total / page_size);

  return (
    <main className="max-w-2xl w-full px-4 py-8 bg-white flex-1">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Tasks</h1>
        <Button asChild>
          <Link href="/tasks/new">New Task</Link>
        </Button>
      </div>

      <div className="mb-4">
        <Suspense>
          <TaskFilters />
        </Suspense>
      </div>

      <TaskList tasks={items} />

      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-6">
          {currentPage > 1 && (
            <Button variant="outline" asChild>
              <Link
                href={`/tasks?page=${currentPage - 1}${filteredStatus ? `&status=${filteredStatus}` : ""}`}
              >
                Previous
              </Link>
            </Button>
          )}
          <span className="text-sm text-muted-foreground self-center">
            Page {currentPage} of {totalPages}
          </span>
          {currentPage < totalPages && (
            <Button variant="outline" asChild>
              <Link
                href={`/tasks?page=${currentPage + 1}${filteredStatus ? `&status=${filteredStatus}` : ""}`}
              >
                Next
              </Link>
            </Button>
          )}
        </div>
      )}
    </main>
  );
}
