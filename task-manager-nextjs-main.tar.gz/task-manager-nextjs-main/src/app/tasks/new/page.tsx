// src/app/tasks/new/page.tsx

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { TaskForm } from "@/components/tasks/TaskForm";
import { createTaskAction } from "@/app/tasks/actions";

export const metadata = {
  title: "Create New Task",
  description:
    "Create a new task, set priorities, and organize your work efficiently in the task manager.",
};

export default function NewTaskPage() {
  return (
    <main className="max-w-2xl w-full px-4 py-8 bg-white flex-1">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">New Task</h1>
        <Button variant="outline" asChild>
          <Link href="/tasks">Back</Link>
        </Button>
      </div>
      <TaskForm action={createTaskAction} />
    </main>
  );
}
