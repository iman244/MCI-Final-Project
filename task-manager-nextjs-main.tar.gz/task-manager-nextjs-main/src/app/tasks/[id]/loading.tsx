export default function TaskDetailLoading() {
  return (
    <main className="max-w-2xl w-full px-4 py-8 bg-white flex-1">
      <div className="flex items-center justify-between mb-6">
        <div className="h-8 w-32 bg-muted rounded animate-pulse" />
        <div className="h-9 w-16 bg-muted rounded animate-pulse" />
      </div>
      <div className="space-y-4">
        <div className="h-10 bg-muted rounded animate-pulse" />
        <div className="h-24 bg-muted rounded animate-pulse" />
        <div className="h-10 bg-muted rounded animate-pulse" />
        <div className="h-9 w-28 bg-muted rounded animate-pulse" />
      </div>
    </main>
  );
}
