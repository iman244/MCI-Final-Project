import Link from "next/link";
import { notFound } from "next/navigation";
import { Button } from "@/components/ui/button";
import { TaskForm } from "@/components/tasks/TaskForm";
import { getTask } from "@/lib/api/tasks";
import { updateTaskAction, deleteTaskAction } from "@/app/tasks/actions";

export const metadata = {
  title: "Edit Task",
  description:
    "Update task details, change status, or remove tasks to keep your work organized and up to date.",
};

interface TaskDetailPageProps {
  params: Promise<{ id: string }>;
}

export default async function TaskDetailPage({ params }: TaskDetailPageProps) {
  const { id } = await params;
  const taskId = Number(id);

  if (isNaN(taskId)) notFound();

  let task;
  try {
    task = await getTask(taskId);
  } catch {
    notFound();
  }

  const updateAction = updateTaskAction.bind(null, taskId);
  const deleteAction = deleteTaskAction.bind(null, taskId);

  return (
    <main className="max-w-2xl w-full px-4 py-8 bg-white flex-1">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Edit Task</h1>
        <Button variant="outline" asChild>
          <Link href="/tasks">Back</Link>
        </Button>
      </div>

      <TaskForm task={task} action={updateAction} />

      <div className="mt-8 pt-6 border-t">
        <form action={deleteAction}>
          <Button type="submit" variant="destructive">
            Delete task
          </Button>
        </form>
      </div>
    </main>
  );
}
