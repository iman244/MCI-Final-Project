export default function TasksLoading() {
  return (
    <main className="max-w-2xl w-full px-4 py-8 bg-white flex-1">
      <div className="flex items-center justify-between mb-6">
        <div className="h-8 w-24 bg-muted rounded animate-pulse" />
        <div className="h-9 w-24 bg-muted rounded animate-pulse" />
      </div>
      <div className="mb-4">
        <div className="h-9 w-48 bg-muted rounded animate-pulse" />
      </div>
      <div className="grid gap-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-20 bg-muted rounded animate-pulse" />
        ))}
      </div>
    </main>
  );
}
