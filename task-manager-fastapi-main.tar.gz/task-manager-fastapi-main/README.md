# Task Manager API

A production-ready REST API for task management built with FastAPI and PostgreSQL, featuring Redis caching, async database access, and a full CI/CD pipeline.

## Tech Stack

- **FastAPI** — async Python web framework
- **PostgreSQL** — primary database
- **SQLAlchemy 2.0** — async ORM
- **Alembic** — database migrations
- **Redis** — caching layer with version-based invalidation
- **Pydantic v2** — data validation and serialization
- **Docker** — containerization
- **GitLab CI** — lint, type check, test, and build pipeline

## Local Setup

### Prerequisites

- Python 3.14
- Docker Desktop

### 1. Clone the repository

```bash
git clone https://gitlab.com/iman244/task-manager-fastapi.git
cd task-manager-fastapi/backend
```

### 2. Create a virtual environment

```bash
python -m venv venv
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Start PostgreSQL and Redis

```bash
docker run -d \
  --name task_manager_db \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=password \
  -e POSTGRES_DB=task_manager \
  -p 5432:5432 \
  postgres

docker run -d \
  --name task_manager_redis \
  -p 6379:6379 \
  redis
```

### 5. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` if needed:

```env
DATABASE_URL=postgresql+asyncpg://postgres:password@localhost:5432/task_manager
REDIS_URL=redis://localhost:6379
```

### 6. Run database migrations

```bash
alembic upgrade head
```

### 7. Start the server

```bash
uvicorn app.main:app --reload
```

API is available at `http://localhost:8000`
Interactive docs at `http://localhost:8000/docs`

### Running with Docker

```bash
docker build -t task-manager-api .
docker run -p 8000:8000 --env-file .env task-manager-api
```

## API Endpoints

### Tasks

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/tasks` | List tasks with optional filtering and pagination |
| `POST` | `/tasks` | Create a new task |
| `GET` | `/tasks/{id}` | Get a task by ID |
| `PUT` | `/tasks/{id}` | Update a task |
| `DELETE` | `/tasks/{id}` | Delete a task |

### Query Parameters for `GET /tasks`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `status` | `todo\|in_progress\|done` | — | Filter by status |
| `title` | `string` | — | Filter by title (case-insensitive) |
| `page` | `integer` | `1` | Page number |
| `page_size` | `integer` | `20` | Items per page (max 100) |

### Health Check

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | Service health check |
