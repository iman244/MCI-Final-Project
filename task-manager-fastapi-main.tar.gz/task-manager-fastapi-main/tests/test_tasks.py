from httpx import AsyncClient


async def test_health(client: AsyncClient) -> None:
    response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


async def test_create_task(client: AsyncClient) -> None:
    response = await client.post(
        "/tasks/",
        json={
            "title": "Buy groceries",
            "description": "Milk, eggs, bread",
            "status": "todo",
        },
    )
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Buy groceries"
    assert data["status"] == "todo"
    assert "id" in data
    assert "created_at" in data


async def test_get_all_tasks_empty(client: AsyncClient) -> None:
    response = await client.get("/tasks/")
    assert response.status_code == 200

    data = response.json()

    assert data["items"] == []
    assert data["total"] == 0
    assert data["page"] == 1
    assert data["page_size"] == 20


async def test_get_all_tasks(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Task 1"})
    await client.post("/tasks/", json={"title": "Task 2"})
    response = await client.get("/tasks/")
    assert response.status_code == 200
    data = response.json()

    assert data["total"] == 2
    assert len(data["items"]) == 2


async def test_get_task_by_id(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "My task"})
    task_id = created.json()["id"]
    response = await client.get(f"/tasks/{task_id}")
    assert response.status_code == 200
    assert response.json()["id"] == task_id


async def test_get_task_not_found(client: AsyncClient) -> None:
    response = await client.get("/tasks/999")
    assert response.status_code == 404
    assert response.json()["detail"] == "Task not found"


async def test_update_task(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "Old title"})
    task_id = created.json()["id"]
    response = await client.put(
        f"/tasks/{task_id}", json={"title": "New title", "status": "in_progress"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "New title"
    assert data["status"] == "in_progress"


async def test_update_task_empty_payload(client: AsyncClient) -> None:
    created = await client.post(
        "/tasks/",
        json={"title": "Original title"},
    )

    task_id = created.json()["id"]

    response = await client.put(
        f"/tasks/{task_id}",
        json={},
    )

    assert response.status_code == 200

    data = response.json()

    assert data["id"] == task_id
    assert data["title"] == "Original title"
    assert data["status"] == "todo"


async def test_update_task_not_found(client: AsyncClient) -> None:
    response = await client.put("/tasks/999", json={"title": "Ghost"})
    assert response.status_code == 404


async def test_delete_task(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "Delete me"})
    task_id = created.json()["id"]
    response = await client.delete(f"/tasks/{task_id}")
    assert response.status_code == 204
    response = await client.get(f"/tasks/{task_id}")
    assert response.status_code == 404


async def test_delete_task_not_found(client: AsyncClient) -> None:
    response = await client.delete("/tasks/999")
    assert response.status_code == 404


async def test_create_task_invalid_title(client: AsyncClient) -> None:
    response = await client.post("/tasks/", json={"title": ""})
    assert response.status_code == 422


async def test_create_task_invalid_status(client: AsyncClient) -> None:
    response = await client.post(
        "/tasks/", json={"title": "Valid title", "status": "not_a_valid_status"}
    )
    assert response.status_code == 422


async def test_filter_by_status(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Task 1", "status": "todo"})
    await client.post("/tasks/", json={"title": "Task 2", "status": "in_progress"})
    await client.post("/tasks/", json={"title": "Task 3", "status": "done"})

    response = await client.get("/tasks/?status=todo")
    assert response.status_code == 200

    data = response.json()
    assert data["total"] == 1
    assert len(data["items"]) == 1
    assert data["items"][0]["status"] == "todo"


async def test_filter_by_title(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Buy groceries"})
    await client.post("/tasks/", json={"title": "Clean house"})
    await client.post("/tasks/", json={"title": "Buy tickets"})

    response = await client.get("/tasks/?title=buy")
    assert response.status_code == 200

    data = response.json()

    assert data["total"] == 2
    assert len(data["items"]) == 2


async def test_filter_by_status_and_title(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Buy groceries", "status": "todo"})
    await client.post("/tasks/", json={"title": "Buy tickets", "status": "done"})
    await client.post("/tasks/", json={"title": "Clean house", "status": "todo"})

    response = await client.get("/tasks/?status=todo&title=buy")
    assert response.status_code == 200

    data = response.json()

    assert data["total"] == 1
    assert len(data["items"]) == 1
    assert data["items"][0]["title"] == "Buy groceries"


async def test_filter_no_results(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Buy groceries"})

    response = await client.get("/tasks/?title=nonexistent")
    assert response.status_code == 200
    data = response.json()

    assert data["items"] == []
    assert data["total"] == 0


async def test_get_tasks_default_pagination(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Task 1"})
    await client.post("/tasks/", json={"title": "Task 2"})

    response = await client.get("/tasks/")

    assert response.status_code == 200

    data = response.json()

    assert data["total"] == 2
    assert data["page"] == 1
    assert data["page_size"] == 20
    assert len(data["items"]) == 2


async def test_get_tasks_last_partial_page(client: AsyncClient) -> None:
    for i in range(5):
        await client.post("/tasks/", json={"title": f"Task {i}"})

    response = await client.get("/tasks/?page=3&page_size=2")

    assert response.status_code == 200

    data = response.json()

    assert data["total"] == 5
    assert data["page"] == 3
    assert len(data["items"]) == 1

    assert data["items"][0]["title"] == "Task 4"


async def test_get_tasks_page_out_of_range(client: AsyncClient) -> None:
    for i in range(3):
        await client.post("/tasks/", json={"title": f"Task {i}"})

    response = await client.get("/tasks/?page=10&page_size=2")

    assert response.status_code == 200

    data = response.json()

    assert data["total"] == 3
    assert data["page"] == 10
    assert data["items"] == []


async def test_filter_pagination_total_count(client: AsyncClient) -> None:
    for i in range(5):
        await client.post(
            "/tasks/",
            json={"title": f"Todo {i}", "status": "todo"},
        )

    for i in range(3):
        await client.post(
            "/tasks/",
            json={"title": f"Done {i}", "status": "done"},
        )

    response = await client.get("/tasks/?status=todo&page=1&page_size=2")

    data = response.json()

    assert response.status_code == 200
    assert data["total"] == 5
    assert len(data["items"]) == 2


async def test_cache_hit_on_second_request(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "Cached task"})
    task_id = created.json()["id"]

    first = await client.get(f"/tasks/{task_id}")
    second = await client.get(f"/tasks/{task_id}")

    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json() == second.json()


async def test_cache_invalidated_on_update(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "Original"})
    task_id = created.json()["id"]

    await client.get(f"/tasks/{task_id}")

    await client.put(f"/tasks/{task_id}", json={"title": "Updated"})

    response = await client.get(f"/tasks/{task_id}")
    assert response.json()["title"] == "Updated"


async def test_cache_invalidated_on_delete(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "To delete"})
    task_id = created.json()["id"]

    await client.get(f"/tasks/{task_id}")

    await client.delete(f"/tasks/{task_id}")

    response = await client.get(f"/tasks/{task_id}")
    assert response.status_code == 404


async def test_task_list_cache_hit(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Task 1"})
    await client.post("/tasks/", json={"title": "Task 2"})

    first = await client.get("/tasks/")
    second = await client.get("/tasks/")

    assert first.status_code == 200
    assert second.status_code == 200
    assert first.json() == second.json()


async def test_task_list_cache_invalidated_on_create(client: AsyncClient) -> None:
    await client.post("/tasks/", json={"title": "Task 1"})
    first = await client.get("/tasks/")
    assert first.json()["total"] == 1

    await client.post("/tasks/", json={"title": "Task 2"})
    second = await client.get("/tasks/")
    assert second.json()["total"] == 2


async def test_task_list_cache_invalidated_on_update(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "Original"})
    task_id = created.json()["id"]

    await client.get("/tasks/")

    await client.put(f"/tasks/{task_id}", json={"title": "Updated"})

    response = await client.get("/tasks/")
    titles = [t["title"] for t in response.json()["items"]]
    assert "Updated" in titles
    assert "Original" not in titles


async def test_task_list_cache_invalidated_on_delete(client: AsyncClient) -> None:
    created = await client.post("/tasks/", json={"title": "To delete"})
    task_id = created.json()["id"]

    await client.get("/tasks/")
    assert (await client.get("/tasks/")).json()["total"] == 1

    await client.delete(f"/tasks/{task_id}")

    response = await client.get("/tasks/")
    assert response.json()["total"] == 0
