from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers.task import router as task_router
from app.schemas import HealthResponse

app = FastAPI(
    title="Task Manager API",
    description="A simple task management API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(task_router)


@app.get(
    "/health",
    response_model=HealthResponse,
    operation_id="healthCheck",
)
async def health_check() -> dict[str, str]:
    return {"status": "ok"}
