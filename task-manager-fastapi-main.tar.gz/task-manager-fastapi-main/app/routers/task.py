from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Any

from app.dependencies import get_db
from app.models.task import TaskStatus
from app.schemas.task import (
    TaskCreate,
    TaskUpdate,
    TaskResponse,
    PaginatedTasksResponse,
)
from app.schemas.common import ErrorResponse
from app.models import Task
from app.services.task import TaskService

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.get(
    "/",
    response_model=PaginatedTasksResponse,
    operation_id="getTasks",
)
async def get_tasks(
    status: TaskStatus | None = Query(default=None),
    title: str | None = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    service = TaskService(db)
    tasks, total = await service.get_tasks(
        status=status,
        title=title,
        page=page,
        page_size=page_size,
    )
    return {
        "items": tasks,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.get(
    "/{task_id}",
    response_model=TaskResponse,
    operation_id="getTask",
    responses={
        404: {
            "model": ErrorResponse,
            "description": "Task not found",
        }
    },
)
async def get_task(task_id: int, db: AsyncSession = Depends(get_db)) -> Task:
    service = TaskService(db)
    task = await service.get_task(task_id)

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@router.post(
    "/",
    response_model=TaskResponse,
    status_code=201,
    operation_id="createTask",
)
async def create_task(data: TaskCreate, db: AsyncSession = Depends(get_db)) -> Task:
    service = TaskService(db)
    return await service.create_task(data)


@router.put(
    "/{task_id}",
    response_model=TaskResponse,
    operation_id="updateTask",
    responses={
        404: {
            "model": ErrorResponse,
            "description": "Task not found",
        }
    },
)
async def update_task(
    task_id: int, data: TaskUpdate, db: AsyncSession = Depends(get_db)
) -> Task:
    service = TaskService(db)
    task = await service.update_task(task_id, data)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


@router.delete(
    "/{task_id}",
    status_code=204,
    operation_id="deleteTask",
    responses={
        404: {
            "model": ErrorResponse,
            "description": "Task not found",
        }
    },
)
async def delete_task(task_id: int, db: AsyncSession = Depends(get_db)) -> None:
    service = TaskService(db)
    deleted = await service.delete_task(task_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Task not found")
