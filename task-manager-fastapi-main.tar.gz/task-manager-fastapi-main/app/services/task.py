import json
from sqlalchemy.ext.asyncio import AsyncSession

from app.cache.redis import redis_client
from app.cache.constants import (
    task_cache_key,
    task_list_cache_key,
    TASK_LIST_VERSION_KEY,
    TASK_CACHE_TTL,
)
from app.repositories.task import TaskRepository
from app.models.task import Task, TaskStatus
from app.schemas.task import TaskCreate, TaskResponse, TaskUpdate


class TaskService:
    def __init__(self, db: AsyncSession):
        self.repo = TaskRepository(db)

    async def _get_tasks_version(self) -> int:
        version = await redis_client.get(TASK_LIST_VERSION_KEY)
        return int(version) if version else 1

    async def get_tasks(
        self,
        status: TaskStatus | None,
        title: str | None,
        page: int,
        page_size: int,
    ) -> tuple[list[Task], int]:
        version = await self._get_tasks_version()
        key = task_list_cache_key(
            version,
            str(status) if status else None,
            title,
            page,
            page_size,
        )

        cached = await redis_client.get(key)
        if cached:
            data = json.loads(cached)
            tasks = [
                Task(
                    **{
                        k: v
                        for k, v in item.items()
                        if k in Task.__mapper__.attrs.keys()
                    }
                )
                for item in data["items"]
            ]
            return tasks, data["total"]

        tasks, total = await self.repo.get_all(
            status=status,
            title=title,
            page=page,
            page_size=page_size,
        )
        payload = {
            "items": [
                TaskResponse.model_validate(t).model_dump(mode="json") for t in tasks
            ],
            "total": total,
        }
        await redis_client.set(key, json.dumps(payload), ex=TASK_CACHE_TTL)
        return tasks, total

    async def get_task(self, task_id: int) -> Task | None:
        key = task_cache_key(task_id)

        cached = await redis_client.get(key)
        if cached:
            data = json.loads(cached)
            return Task(
                **{k: v for k, v in data.items() if k in Task.__mapper__.attrs.keys()}
            )

        task = await self.repo.get_by_id(task_id)
        if task:
            await redis_client.set(
                key,
                json.dumps(TaskResponse.model_validate(task).model_dump(mode="json")),
                ex=TASK_CACHE_TTL,
            )
        return task

    async def create_task(self, data: TaskCreate) -> Task:
        task = await self.repo.create(data)
        await self.invalidate_task_lists()
        return task

    async def update_task(self, task_id: int, data: TaskUpdate) -> Task | None:
        task = await self.repo.update(task_id, data)
        if task:
            await self.invalidate_task(task_id)
            await self.invalidate_task_lists()
        return task

    async def delete_task(self, task_id: int) -> bool:
        deleted = await self.repo.delete(task_id)
        if deleted:
            await self.invalidate_task(task_id)
            await self.invalidate_task_lists()
        return deleted

    async def invalidate_task(self, task_id: int) -> None:
        await redis_client.delete(task_cache_key(task_id))

    async def invalidate_task_lists(self) -> None:
        await redis_client.incr(TASK_LIST_VERSION_KEY)
