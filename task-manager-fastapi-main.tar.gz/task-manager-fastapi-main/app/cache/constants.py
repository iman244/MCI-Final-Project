TASK_CACHE_PREFIX = "task"
TASK_LIST_CACHE_PREFIX = "tasks"
TASK_LIST_VERSION_KEY = "tasks:version"
TASK_CACHE_TTL = 300  # 5 minutes


def task_cache_key(task_id: int) -> str:
    return f"{TASK_CACHE_PREFIX}:{task_id}"


def task_list_cache_key(
    version: int,
    status: str | None,
    title: str | None,
    page: int,
    page_size: int,
) -> str:
    return f"{TASK_LIST_CACHE_PREFIX}:v{version}:{status}:{title}:{page}:{page_size}"
