from sqlalchemy import select, update, delete, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.task import Task, TaskStatus
from app.schemas.task import TaskCreate, TaskUpdate


class TaskRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_all(
        self,
        status: TaskStatus | None = None,
        title: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> tuple[list[Task], int]:
        query = select(Task)

        if status is not None:
            query = query.where(Task.status == status)

        if title is not None:
            query = query.where(Task.title.ilike(f"%{title}%"))

        # total count
        count_query = select(func.count()).select_from(query.subquery())
        total = await self.db.scalar(count_query)

        # pagination
        query = query.offset((page - 1) * page_size).limit(page_size)

        result = await self.db.execute(query)

        return list(result.scalars().all()), total or 0

    async def get_by_id(self, task_id: int) -> Task | None:
        result = await self.db.execute(select(Task).where(Task.id == task_id))
        return result.scalar_one_or_none()

    async def create(self, data: TaskCreate) -> Task:
        task = Task(**data.model_dump())
        self.db.add(task)
        await self.db.flush()
        await self.db.refresh(task)
        return task

    async def update(self, task_id: int, data: TaskUpdate) -> Task | None:
        values = {k: v for k, v in data.model_dump().items() if v is not None}
        if not values:
            return await self.get_by_id(task_id)

        await self.db.execute(update(Task).where(Task.id == task_id).values(**values))
        await self.db.flush()
        return await self.get_by_id(task_id)

    async def delete(self, task_id: int) -> bool:
        result = await self.db.execute(delete(Task).where(Task.id == task_id))
        return bool(result.rowcount and result.rowcount > 0)  # type: ignore[attr-defined]
